## Steps of running this sample application
- Download the whole repository and create an analytical project on CP4D following documentation

- Open RStudio and upload sample application zip file  

- Open `app.r` and run 
